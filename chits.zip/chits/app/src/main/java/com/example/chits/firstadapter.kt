package com.example.chits

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class firstadapter(private val firstlist: List<firstitem>): RecyclerView.Adapter<firstadapter.firstviewholder>() {


    class firstviewholder(itemView: View): RecyclerView.ViewHolder(itemView){
        val firstimage: ImageView = itemView.findViewById(R.id.firstcardimage)
        val firsttext: TextView = itemView.findViewById(R.id.firstcardtext)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): firstviewholder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.firstcard,parent , false)
        return firstviewholder(itemView)
    }

    override fun getItemCount() = firstlist.size

    override fun onBindViewHolder(holder: firstviewholder, position: Int) {
        val currentitem = firstlist[position]
        holder.firstimage.setImageResource(currentitem.firstimage)
        holder.firsttext.text = currentitem.firsttext
    }
}