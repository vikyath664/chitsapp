package com.example.chits

data class firstitem(val firstimage: Int, val firsttext : String)
