package com.example.chits

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val grouplist : List<firstitem>
        val list = ArrayList<firstitem>()
        val item1 =firstitem(R.drawable.ic_launcher_foreground, "first product")
        list +=item1
        val item =firstitem(R.drawable.ic_launcher_background, "second product")
        list +=item
        grouplist=list

        recyclerView.adapter= firstadapter(grouplist)
        recyclerView.layoutManager= LinearLayoutManager(this)
    }
}
